package com.ohgiraffers.jwtrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
